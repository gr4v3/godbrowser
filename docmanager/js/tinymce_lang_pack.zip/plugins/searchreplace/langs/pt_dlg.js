tinyMCE.addI18n('pt.searchreplace_dlg',{
searchnext_desc:"Localizar novamente",
notfound:"Pesquisa conclu\u00EDda sem resultados.",
search_title:"Localizar",
replace_title:"Localizar/Substituir",
allreplaced:"Todas substitui\u00E7\u00F5es foram efetuadas.",
findwhat:"Localizar o qu\u00EA",
replacewith:"Substituir com o qu\u00EA",
direction:"Dire\u00E7\u00E3o",
up:"Subir",
down:"Descer",
mcase:"Diferenciar mai\u00FAsculas/min\u00FAsculas",
findnext:"Localizar o seguinte",
replace:"Substituir",
replaceall:"Substituir todos"
});