tinyMCE.addI18n('pt.simple',{
bold_desc:"Negrito (Ctrl+B)",
italic_desc:"It\u00E1lico (Ctrl+I)",
underline_desc:"Sublinhado (Ctrl+U)",
striketrough_desc:"Texto Riscado",
bullist_desc:"Lista N\u00E3o-Ordenada",
numlist_desc:"Lista Ordenada",
undo_desc:"Desfazer (Ctrl+Z)",
redo_desc:"Refazer (Ctrl+Y)",
cleanup_desc:"Limpar C\u00F3digo Incorreto"
});