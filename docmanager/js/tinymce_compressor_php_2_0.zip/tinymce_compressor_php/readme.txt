Check this wiki page for installation instructions:
http://wiki.moxiecode.com/index.php/TinyMCE:Compressor/PHP
